Smart Patient Monitoring System Local Backup
Created at: 2026-06-01 08:37:23
Created by: Yasen
SQLite database entry: data/smart_patient_monitoring.db
Upload files included from: data/uploads/
Upload file count: 8
Scope: Local backup only. No cloud upload and no encryption in Phase 30.
Restore behavior: JavaFX currently supports preview/validation only. It does not overwrite the live database.
